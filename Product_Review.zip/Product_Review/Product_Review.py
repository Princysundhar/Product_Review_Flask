from flask import Flask,render_template,request,redirect,session
import time
from DBConnection import Db
app = Flask(__name__)
static_path=r"C:\Users\HP\PycharmProjects\Product_Review\static\\"

app.secret_key="1234"

@app.route('/')
def hello_world():
    return render_template("index.html")


@app.route('/login_post',methods=['post'])
def login_post():
    username=request.form['textfield']
    password=request.form['textfield2']
    db=Db()
    data = db.selectOne("select * from login where username='"+username+"' and password='"+password+"'")

    if data is None:
        return "<script>alert('Invalid User')</script>"
    else:
        session['lid']=data['login_id']

        if data['type'] == 'admin':
            return redirect('/adminhome')
        else:
            return redirect('/userhome')


@app.route('/adminhome')
def adminhome():
    return render_template("admin/index.html")

@app.route('/userhome')
def userhome():
    return render_template("user/index.html")

@app.route('/view_user')
def view_user():
    db=Db()
    data=db.select("select * from user")
    return render_template("admin/view_registered_user.html",data=data)

@app.route('/product')
def product():
    return render_template("admin/add_product.html")

@app.route('/product_post',methods=['post'])
def product_post():
    product_name=request.form['textfield']
    product_price=request.form['textfield2']
    description=request.form['textarea']
    photo=request.files['fileField']
    dt=time.strftime("%Y%m%d_%H%M%S")
    photo.save(static_path + "image\\" + dt + ".jpg")
    path = "/static/image/" + dt + ".jpg"
    db=Db()
    db.insert("insert into product(product_name,product_price,description,photo) values('"+product_name+"','"+product_price+"','"+description+"','"+path+"')")
    return "<script>alert('product Added');window.location='/view_product'</script>"

@app.route('/view_product')
def view_product():
    db=Db()
    data=db.select("select * from product")
    return render_template("admin/view_product.html",data=data)


@app.route('/update_product/<i>')
def update_product(i):
    db=Db()
    data=db.selectOne("select * from product where product_id='"+i+"'")
    return render_template("admin/update_product.html",data=data,data1=data)

@app.route('/update_product_post/<i>',methods=['post'])
def update_product_post(i):
    product_name = request.form['textfield']
    product_price = request.form['textfield2']
    description = request.form['textarea']
    db=Db()
    if request.files is not None:
        photo = request.files['fileField']
        if photo.filename != "":
            dt = time.strftime("%Y%m%d_%H%M%S")
            photo.save(static_path + "image\\" + dt + ".jpg")
            path = "/static/image/" + dt + ".jpg"
            db.update("update product set photo='" + path + "' where product_id='" + i + "'")

    db.update("update product set product_name='"+product_name+"',product_price='"+product_price+"',description='"+description+"' where product_id='"+i+"'")
    return redirect('/view_product')


@app.route('/delete_product/<i>')
def delete_product(i):
    db=Db()
    db.delete("delete from product where product_id='"+i+"'")
    return "<script>alert('product Removed');window.location='/view_product'</script>"


@app.route('/view_product_review/<i>')
def view_product_review(i):
    db=Db()
    data=db.select("select * from product,review,user where product.product_id=review.product_id and user.user_id=review.user_id and product.product_id='"+i+"'")
    return render_template("admin/view_product_review.html", data=data)


@app.route('/view_complaint')
def view_complaint():
    db=Db()
    data=db.select("select * from user,complaint where user.user_id=complaint.user_id")
    return render_template("admin/view_complaint.html",data=data)

@app.route('/send_reply/<i>')
def reply(i):
    db=Db()
    return render_template("admin/send_reply.html",data=i)

@app.route('/send_reply_post/<i>',methods=['post'])
def reply_post(i):
    reply=request.form['textarea']
    db=Db()
    db.update("update complaint set reply='"+reply+"',reply_date=curdate() where complaint_id='"+i+"'")
    return redirect('/view_complaint')


@app.route('/register')
def register():
    return render_template("user/Register.html")

@app.route('/register_post',methods=['post'])
def register_post():
    username=request.form['textfield']
    gender=request.form['RadioGroup1']
    house_name=request.form['textfield2']
    place=request.form['textfield3']
    post=request.form['textfield4']
    pin=request.form['textfield5']
    email=request.form['textfield6']
    phone_no=request.form['textfield7']
    password=request.form['textfield8']
    db=Db()
    query1=db.insert("insert into login(username,password,type) values('"+email+"','"+password+"','user')")
    db.insert("insert into user(user_id,username,gender,house_name,place,post,pin,email,phone_no) values ('"+str(query1)+"','"+username+"','"+gender+"','"+house_name+"','"+place+"','"+post+"','"+pin+"','"+email+"','"+phone_no+"')")
    return "<script>alert('Registered successfully');window.location='/'</script>"


@app.route('/product_view')
def product_view():
    db=Db()
    data=db.select("select * from product")
    return render_template("user/product_view.html",data=data)

@app.route('/view_review/<i>')
def view_review(i):
    db=Db()
    data=db.select("select * from review,user,product where user.user_id=review.user_id and product.product_id='"+i+"'")
    return render_template("user/view_review.html",data=data)

@app.route('/send_review/<i>')
def send_review(i):
    return render_template("user/send_product_review.html",data=i)

@app.route('/send_review_post/<i>',methods=['post'])
def send_review_post(i):
    review = request.form['textarea']
    db=Db()
    db.insert("insert into review(review,review_date,user_id,product_id) values('"+review+"',curdate(),'"+str(session['lid'])+"','"+i+"')")
    return "<script>alert('Review send');window.location='/product_view'</script>"



@app.route('/send_complaint')
def send_compliant():
    return render_template("user/send_complaint.html")

@app.route('/post_complaint',methods=['post'])
def post_compliant():
    complaint=request.form['textarea']
    db=Db()
    db.insert("insert into complaint(user_id,complaint,complaint_date) values('"+str(session['lid'])+"','"+complaint+"',curdate())")
    return "<script>alert('complaint send');window.location='/send_complaint'</script>"

@app.route('/view_reply')
def view_reply():
    db=Db()
    data=db.select("select * from complaint where user_id='"+str(session['lid'])+"'")
    return render_template("user/view_reply.html",data=data)


@app.route('/change_password')
def change_password():
    return render_template("admin/change_password.html")

@app.route('/change_password_post',methods=['post'])
def change_password_post():
    old_password=request.form['textfield1']
    new_password=request.form['textfield2']
    confirm_password=request.form['textfield3']
    db=Db()
    q=db.selectOne("select * from login where password='"+old_password+"' and login_id='"+str(session['lid'])+"'")
    if q is not None:
        if new_password==confirm_password:
            q=db.selectOne("select * from login where password='"+new_password+"'")
            if  q is None:
                db.update("update login set password='"+new_password+"' where login_id='"+str(session['lid'])+"' ")
                return "<script>alert('password updated');window.location='/'</script>"
            else:
                return "<script>alert('password already exist');window.location='/change_password'</script>"
        else:
            return "<script>alert('Mismatch');window.location='/change_password'</script>"
    else:
        return "<script>alert('old password doesnot match');window.location='/change_password'</script>"


@app.route('/change_password_user')
def change_password_user():
    return render_template("user/change_password.html")

@app.route('/change_password_user_post',methods=['post'])
def change_password_user_post():
    old_password=request.form['textfield1']
    new_password=request.form['textfield2']
    confirm_password=request.form['textfield3']
    db=Db()
    q=db.selectOne("select * from login where password='"+old_password+"' and login_id='"+str(session['lid'])+"'")
    if q is not None:
        if new_password==confirm_password:
            q=db.selectOne("select * from login where password='"+new_password+"'")
            if  q is None:
                db.update("update login set password='"+new_password+"' where login_id='"+str(session['lid'])+"' ")
                return "<script>alert('password updated');window.location='/'</script>"
            else:
                return "<script>alert('password already exist');window.location='/change_password_user'</script>"
        else:
            return "<script>alert('Mismatch');window.location='/change_password_user'</script>"
    else:
        return "<script>alert('old password doesnot match');window.location='/change_password_user'</script>"









if __name__ == '__main__':
    app.run(port=4000)
